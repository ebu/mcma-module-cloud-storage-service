"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const api_1 = require("@mcma/api");
const azure_cosmos_db_1 = require("@mcma/azure-cosmos-db");
const azure_logger_1 = require("@mcma/azure-logger");
const azure_functions_api_1 = require("@mcma/azure-functions-api");
const azure_key_vault_1 = require("@mcma/azure-key-vault");
const azure_queue_worker_invoker_1 = require("@mcma/azure-queue-worker-invoker");
const loggerProvider = new azure_logger_1.AppInsightsLoggerProvider("cloud-storage-service-api-handler");
const dbTableProvider = new azure_cosmos_db_1.CosmosDbTableProvider((0, azure_cosmos_db_1.fillOptionsFromConfigVariables)());
const secretsProvider = new azure_key_vault_1.AzureKeyVaultSecretsProvider();
const workerInvoker = new azure_queue_worker_invoker_1.QueueWorkerInvoker();
const securityMiddleware = new api_1.McmaApiKeySecurityMiddleware({ secretsProvider });
const routes = new api_1.DefaultJobRouteCollection(dbTableProvider, workerInvoker);
const restController = new azure_functions_api_1.AzureFunctionApiController({
    routes,
    loggerProvider,
    middleware: [securityMiddleware],
});
const handler = async (context, request) => {
    const logger = await loggerProvider.get(context.invocationId);
    try {
        logger.functionStart(context.invocationId);
        logger.debug(context);
        logger.debug(request);
        return await restController.handleRequest(request);
    }
    catch (error) {
        logger.error(error);
        throw error;
    }
    finally {
        logger.functionEnd(context.invocationId);
        loggerProvider.flush();
    }
};
exports.handler = handler;
