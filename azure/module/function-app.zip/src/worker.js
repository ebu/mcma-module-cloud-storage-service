"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.workerQueueHandler = workerQueueHandler;
const client_1 = require("@mcma/client");
const worker_1 = require("@mcma/worker");
const azure_logger_1 = require("@mcma/azure-logger");
const azure_key_vault_1 = require("@mcma/azure-key-vault");
const azure_cosmos_db_1 = require("@mcma/azure-cosmos-db");
const azure_queue_worker_invoker_1 = require("@mcma/azure-queue-worker-invoker");
const storage_1 = require("@local/storage");
const worker_2 = require("@local/worker");
const loggerProvider = new azure_logger_1.AppInsightsLoggerProvider("cloud-storage-service-worker");
const dbTableProvider = new azure_cosmos_db_1.CosmosDbTableProvider((0, azure_cosmos_db_1.fillOptionsFromConfigVariables)());
const secretsProvider = new azure_key_vault_1.AzureKeyVaultSecretsProvider();
const authProvider = new client_1.AuthProvider().add((0, client_1.mcmaApiKeyAuth)({ secretsProvider }));
const resourceManagerProvider = new client_1.ResourceManagerProvider(authProvider);
const workerInvoker = new azure_queue_worker_invoker_1.QueueWorkerInvoker();
const storageClientFactory = new storage_1.StorageClientFactory({
    secretsProvider,
});
const worker = (0, worker_2.buildWorker)(dbTableProvider, loggerProvider, resourceManagerProvider, secretsProvider);
async function workerQueueHandler(queueItem, context) {
    const queueMessage = queueItem;
    const logger = await loggerProvider.get(context.invocationId, queueMessage.tracker);
    try {
        logger.functionStart(context.invocationId);
        logger.debug(context);
        logger.debug(queueMessage);
        // assume 5 mins function timeout
        let functionTimeLimit = new Date(Date.now() + 300000);
        logger.info("AzureFunctionsJobHost__functionTimeout = " + process.env.AzureFunctionsJobHost__functionTimeout);
        const functionTimeout = process.env.AzureFunctionsJobHost__functionTimeout;
        if (functionTimeout) {
            const parts = functionTimeout.split(":");
            if (parts.length === 3) {
                const durationInSeconds = Number.parseInt(parts[0]) * 3600 + Number.parseInt(parts[1]) * 60 + Number.parseInt(parts[2]);
                functionTimeLimit = new Date(Date.now() + durationInSeconds * 1000);
            }
        }
        const workerContext = {
            requestId: context.invocationId,
            secretsProvider,
            storageClientFactory,
            functionTimeLimit,
            workerInvoker,
        };
        await worker.doWork(new worker_1.WorkerRequest(queueMessage, logger), workerContext);
    }
    catch (error) {
        logger.error(error.message);
        logger.error(error);
    }
    finally {
        logger.functionEnd(context.invocationId);
        loggerProvider.flush();
    }
}
