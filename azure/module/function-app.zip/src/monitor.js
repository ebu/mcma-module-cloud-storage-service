"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.monitor = monitor;
const uuid_1 = require("uuid");
const core_1 = require("@mcma/core");
const azure_cosmos_db_1 = require("@mcma/azure-cosmos-db");
const azure_logger_1 = require("@mcma/azure-logger");
const azure_queue_worker_invoker_1 = require("@mcma/azure-queue-worker-invoker");
const storage_1 = require("@local/storage");
const monitor_1 = require("@local/monitor");
const azure_key_vault_1 = require("@mcma/azure-key-vault");
const loggerProvider = new azure_logger_1.AppInsightsLoggerProvider("cloud-storage-service-monitor");
const dbTableProvider = new azure_cosmos_db_1.CosmosDbTableProvider((0, azure_cosmos_db_1.fillOptionsFromConfigVariables)());
const secretsProvider = new azure_key_vault_1.AzureKeyVaultSecretsProvider();
const workerInvoker = new azure_queue_worker_invoker_1.QueueWorkerInvoker();
const storageClientFactory = new storage_1.StorageClientFactory({
    secretsProvider,
});
async function monitor(timer, context) {
    const tracker = new core_1.McmaTracker({
        id: (0, uuid_1.v4)(),
        label: "Monitor - " + new Date().toUTCString()
    });
    const logger = await loggerProvider.get(context.invocationId, tracker);
    try {
        logger.functionStart(context.invocationId);
        logger.debug(context);
        logger.debug(timer);
        const monitor = new monitor_1.Monitor({
            dbTableProvider,
            storageClientFactory,
            workerInvoker,
        });
        await monitor.run(logger);
    }
    catch (error) {
        logger.error(error);
        throw error;
    }
    finally {
        logger.functionEnd(context.invocationId);
        loggerProvider.flush();
    }
}
