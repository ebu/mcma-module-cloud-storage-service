"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_lambda_1 = require("@aws-sdk/client-lambda");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const api_1 = require("@mcma/api");
const aws_dynamodb_1 = require("@mcma/aws-dynamodb");
const aws_lambda_worker_invoker_1 = require("@mcma/aws-lambda-worker-invoker");
const aws_api_gateway_1 = require("@mcma/aws-api-gateway");
const core_1 = require("@mcma/core");
const aws_secrets_manager_1 = require("@mcma/aws-secrets-manager");
const aws_xray_sdk_core_1 = require("aws-xray-sdk-core");
const secretsManagerClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_secrets_manager_1.SecretsManagerClient({}));
const dynamoDBClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_dynamodb_1.DynamoDBClient({}));
const lambdaClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_lambda_1.LambdaClient({}));
const secretsProvider = new aws_secrets_manager_1.AwsSecretsManagerSecretsProvider({ client: secretsManagerClient });
const dbTableProvider = new aws_dynamodb_1.DynamoDbTableProvider({}, dynamoDBClient);
const loggerProvider = new core_1.ConsoleLoggerProvider("cloud-storage-service-api-handler");
const workerInvoker = new aws_lambda_worker_invoker_1.LambdaWorkerInvoker(lambdaClient);
const routes = new api_1.DefaultJobRouteCollection(dbTableProvider, workerInvoker);
const middleware = [];
if (process.env.MCMA_API_KEY_SECURITY_CONFIG_SECRET_ID) {
    const securityMiddleware = new api_1.McmaApiKeySecurityMiddleware({ secretsProvider });
    middleware.push(securityMiddleware);
}
const restController = new aws_api_gateway_1.ApiGatewayApiController({
    routes,
    loggerProvider,
    middleware,
});
async function handler(event, context) {
    const logger = await loggerProvider.get(context.awsRequestId);
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        return await restController.handleRequest(event, context);
    }
    catch (error) {
        logger.error(error);
        throw error;
    }
    finally {
        logger.functionEnd(context.awsRequestId);
    }
}
exports.handler = handler;
