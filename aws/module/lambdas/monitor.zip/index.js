"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const client_cloudwatch_logs_1 = require("@aws-sdk/client-cloudwatch-logs");
const client_s3_1 = require("@aws-sdk/client-s3");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_lambda_1 = require("@aws-sdk/client-lambda");
const aws_xray_sdk_core_1 = require("aws-xray-sdk-core");
const aws_logger_1 = require("@mcma/aws-logger");
const aws_secrets_manager_1 = require("@mcma/aws-secrets-manager");
const aws_dynamodb_1 = require("@mcma/aws-dynamodb");
const aws_lambda_worker_invoker_1 = require("@mcma/aws-lambda-worker-invoker");
const storage_1 = require("@local/storage");
const monitor_1 = require("@local/monitor");
const data_1 = require("@mcma/data");
const cloudWatchLogsClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_cloudwatch_logs_1.CloudWatchLogsClient({}));
const dynamoDBClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_dynamodb_1.DynamoDBClient({}));
const lambdaClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_lambda_1.LambdaClient({}));
const secretsManagerClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_secrets_manager_1.SecretsManagerClient({}));
const dbTableProvider = new aws_dynamodb_1.DynamoDbTableProvider({}, dynamoDBClient);
const secretsProvider = new aws_secrets_manager_1.AwsSecretsManagerSecretsProvider({ client: secretsManagerClient });
const loggerProvider = new aws_logger_1.AwsCloudWatchLoggerProvider("cloud-storage-service-monitor", (0, aws_logger_1.getLogGroupName)(), cloudWatchLogsClient);
const workerInvoker = new aws_lambda_worker_invoker_1.LambdaWorkerInvoker(lambdaClient);
const buildS3Client = config => !config.endpoint ? (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_s3_1.S3Client(config)) : new client_s3_1.S3Client(config);
const storageClientFactory = new storage_1.StorageClientFactory({
    secretsProvider,
    buildS3Client,
});
async function handler(event, context) {
    const logger = await loggerProvider.get(context.awsRequestId);
    const table = await dbTableProvider.get((0, data_1.getTableName)());
    const mutex = table.createMutex({
        name: "cloud-storage-service-monitor",
        holder: context.awsRequestId,
        logger,
        lockTimeout: 15 * 60 * 1000, // 15 mins lock
    });
    const lock = await mutex.tryLock();
    if (!lock) {
        return;
    }
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        const monitor = new monitor_1.Monitor({
            dbTableProvider,
            storageClientFactory,
            workerInvoker,
        });
        await monitor.run(logger);
    }
    catch (error) {
        logger.error(error);
    }
    finally {
        await mutex.unlock();
        logger.functionEnd(context.awsRequestId);
        await loggerProvider.flush();
    }
}
//# sourceMappingURL=index.js.map