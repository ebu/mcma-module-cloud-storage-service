"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const aws_xray_sdk_core_1 = require("aws-xray-sdk-core");
const client_cloudwatch_logs_1 = require("@aws-sdk/client-cloudwatch-logs");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_s3_1 = require("@aws-sdk/client-s3");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const client_1 = require("@mcma/client");
const worker_1 = require("@mcma/worker");
const aws_dynamodb_1 = require("@mcma/aws-dynamodb");
const aws_logger_1 = require("@mcma/aws-logger");
const aws_client_1 = require("@mcma/aws-client");
const aws_secrets_manager_1 = require("@mcma/aws-secrets-manager");
const storage_1 = require("@local/storage");
const worker_2 = require("@local/worker");
const client_lambda_1 = require("@aws-sdk/client-lambda");
const aws_lambda_worker_invoker_1 = require("@mcma/aws-lambda-worker-invoker");
const cloudWatchLogsClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_cloudwatch_logs_1.CloudWatchLogsClient({}));
const dynamoDBClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_dynamodb_1.DynamoDBClient({}));
const lambdaClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_lambda_1.LambdaClient({}));
const secretsManagerClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_secrets_manager_1.SecretsManagerClient({}));
const secretsProvider = new aws_secrets_manager_1.AwsSecretsManagerSecretsProvider({ client: secretsManagerClient });
const authProvider = new client_1.AuthProvider().add((0, aws_client_1.awsV4Auth)()).add((0, client_1.mcmaApiKeyAuth)({ secretsProvider }));
const dbTableProvider = new aws_dynamodb_1.DynamoDbTableProvider({}, dynamoDBClient);
const loggerProvider = new aws_logger_1.AwsCloudWatchLoggerProvider("cloud-storage-service-worker", (0, aws_logger_1.getLogGroupName)(), cloudWatchLogsClient);
const resourceManagerProvider = new client_1.ResourceManagerProvider(authProvider);
const workerInvoker = new aws_lambda_worker_invoker_1.LambdaWorkerInvoker(lambdaClient);
const buildS3Client = config => !config.endpoint ? (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_s3_1.S3Client(config)) : new client_s3_1.S3Client(config);
const storageClientFactory = new storage_1.StorageClientFactory({
    secretsProvider,
    buildS3Client,
});
const worker = (0, worker_2.buildWorker)(dbTableProvider, loggerProvider, resourceManagerProvider, secretsProvider);
async function handler(event, context) {
    const logger = await loggerProvider.get(context.awsRequestId, event.tracker);
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        const workerContext = {
            requestId: context.awsRequestId,
            secretsProvider,
            storageClientFactory,
            functionTimeLimit: new Date(Date.now() + context.getRemainingTimeInMillis()),
            workerInvoker,
        };
        await worker.doWork(new worker_1.WorkerRequest(event, logger), workerContext);
    }
    catch (error) {
        logger.error("Error occurred when handling operation '" + event.operationName + "'");
        logger.error(error);
    }
    finally {
        logger.functionEnd(context.awsRequestId);
        await loggerProvider.flush();
    }
}
