"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const aws_xray_sdk_core_1 = require("aws-xray-sdk-core");
const client_cloudwatch_logs_1 = require("@aws-sdk/client-cloudwatch-logs");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_s3_1 = require("@aws-sdk/client-s3");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const client_lambda_1 = require("@aws-sdk/client-lambda");
const aws_lambda_worker_invoker_1 = require("@mcma/aws-lambda-worker-invoker");
const core_1 = require("@mcma/core");
const client_1 = require("@mcma/client");
const worker_1 = require("@mcma/worker");
const aws_dynamodb_1 = require("@mcma/aws-dynamodb");
const aws_logger_1 = require("@mcma/aws-logger");
const aws_client_1 = require("@mcma/aws-client");
const aws_secrets_manager_1 = require("@mcma/aws-secrets-manager");
const storage_1 = require("@local/storage");
const worker_2 = require("@local/worker");
function captureAWSv3Client(client, manualSegment) {
    if (process.env.RUN_LOCAL === "true") {
        return client;
    }
    return (0, aws_xray_sdk_core_1.captureAWSv3Client)(client);
}
function buildLoggerProvider() {
    if (process.env.RUN_LOCAL === "true") {
        return new core_1.ConsoleLoggerProvider("cloud-storage-service-worker");
    }
    return new aws_logger_1.AwsCloudWatchLoggerProvider("cloud-storage-service-worker", (0, aws_logger_1.getLogGroupName)(), captureAWSv3Client(new client_cloudwatch_logs_1.CloudWatchLogsClient({})));
}
const dynamoDBClient = captureAWSv3Client(new client_dynamodb_1.DynamoDBClient({}));
const lambdaClient = captureAWSv3Client(new client_lambda_1.LambdaClient({}));
const secretsManagerClient = captureAWSv3Client(new client_secrets_manager_1.SecretsManagerClient({}));
const secretsProvider = new aws_secrets_manager_1.AwsSecretsManagerSecretsProvider({ client: secretsManagerClient });
const authProvider = new client_1.AuthProvider().add((0, aws_client_1.awsV4Auth)()).add((0, client_1.mcmaApiKeyAuth)({ secretsProvider }));
const dbTableProvider = new aws_dynamodb_1.DynamoDbTableProvider({}, dynamoDBClient);
const loggerProvider = buildLoggerProvider();
const resourceManagerProvider = new client_1.ResourceManagerProvider(authProvider);
const workerInvoker = new aws_lambda_worker_invoker_1.LambdaWorkerInvoker(lambdaClient);
const buildS3Client = config => !config.endpoint ? captureAWSv3Client(new client_s3_1.S3Client(config)) : new client_s3_1.S3Client(config);
const configVariables = new core_1.ConfigVariables();
const s3ClientForState = buildS3Client({});
const storageClientFactory = new storage_1.StorageClientFactory({
    secretsProvider,
    buildS3Client,
});
const worker = (0, worker_2.buildWorker)(dbTableProvider, loggerProvider, resourceManagerProvider, secretsProvider);
function computeBucketAndKey(jobAssignmentId) {
    const bucket = configVariables.get("TEMP_BUCKET");
    const jobAssignmentGuid = jobAssignmentId.substring(jobAssignmentId.lastIndexOf("/") + 1);
    const stateKey = `${configVariables.get("TEMP_BUCKET_PREFIX")}${jobAssignmentGuid}.json`;
    const trieKey = `${configVariables.get("TEMP_BUCKET_PREFIX")}${jobAssignmentGuid}.trie.gz`;
    return { bucket, stateKey, trieKey };
}
async function loadFileCopierState(jobAssignmentId) {
    const { bucket, stateKey, trieKey } = computeBucketAndKey(jobAssignmentId);
    const output = await s3ClientForState.send(new client_s3_1.GetObjectCommand({
        Bucket: bucket,
        Key: stateKey,
    }));
    const content = await output.Body.transformToString();
    const state = JSON.parse(content, core_1.Utils.reviver);
    const trie = await (0, storage_1.loadTrieFromS3)(s3ClientForState, bucket, trieKey);
    return {
        filesTotal: state.filesTotal,
        filesCopied: state.filesCopied,
        bytesTotal: state.bytesTotal,
        bytesCopied: state.bytesCopied,
        workItems: state.workItems,
        trie
    };
}
async function saveFileCopierState(jobAssignmentId, state) {
    const { bucket, stateKey, trieKey } = computeBucketAndKey(jobAssignmentId);
    await s3ClientForState.send(new client_s3_1.PutObjectCommand({
        Bucket: bucket,
        Key: stateKey,
        Body: JSON.stringify({
            filesTotal: state.filesTotal,
            filesCopied: state.filesCopied,
            bytesTotal: state.bytesTotal,
            bytesCopied: state.bytesCopied,
            workItems: state.workItems,
        }),
    }));
    await (0, storage_1.saveTrieToS3)(state.trie, s3ClientForState, bucket, trieKey);
}
async function deleteFileCopierState(jobAssignmentId) {
    const { bucket, stateKey, trieKey } = computeBucketAndKey(jobAssignmentId);
    await s3ClientForState.send(new client_s3_1.DeleteObjectCommand({
        Bucket: bucket,
        Key: stateKey,
    }));
    await s3ClientForState.send(new client_s3_1.DeleteObjectCommand({
        Bucket: bucket,
        Key: trieKey,
    }));
}
async function handler(event, context) {
    const logger = await loggerProvider.get(context.awsRequestId, event.tracker);
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        const workerContext = {
            requestId: context.awsRequestId,
            functionTimeLimit: new Date(Date.now() + context.getRemainingTimeInMillis()),
            secretsProvider,
            storageClientFactory,
            workerInvoker,
            loadFileCopierState,
            saveFileCopierState,
            deleteFileCopierState,
        };
        await worker.doWork(new worker_1.WorkerRequest(event, logger), workerContext);
    }
    catch (error) {
        logger.error("Error occurred when handling operation '" + event.operationName + "'");
        logger.error(error);
    }
    finally {
        logger.functionEnd(context.awsRequestId);
        if (process.env.RUN_LOCAL !== "true") {
            await loggerProvider.flush();
        }
    }
}
//# sourceMappingURL=index.js.map